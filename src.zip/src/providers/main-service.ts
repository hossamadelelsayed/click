export class MainService {

  public static  baseUrl : string = "http://click-qa.com/";
  public static  lang : string = 'en';
  // Paypal
  public static payPalEnvironmentSandbox = 'AQVCB0GR1LZ6TxG_kRLUzCch-fUxwyav0xoK3AgJxJEpVbufN2eCy4XnlqcdMVqiMWsvPePNVCI4-Dc1';
  public static payPalEnvironmentProduction = '';
}
